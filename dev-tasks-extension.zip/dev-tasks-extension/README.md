# Dev Tasks · Guardar en Recursos (extensión)

Guarda la página que estás viendo en los **Recursos** de tu web con **un solo clic**,
sin abrir otra pestaña ni pegar nada.

Funciona en Chrome, Edge, Brave y Opera (navegadores basados en Chromium).

## Instalar (1 minuto)

1. Descomprime esta carpeta donde no la vayas a borrar (por ejemplo `Documentos\dev-tasks-extension`).
2. Abre `chrome://extensions` (en Edge: `edge://extensions`, en Brave: `brave://extensions`).
3. Activa **Modo de desarrollador** (arriba a la derecha).
4. Pulsa **Cargar descomprimida** y elige la carpeta `dev-tasks-extension`.
5. Pulsa el icono del puzzle de la barra del navegador y **ancla** la extensión (la chincheta)
   para tener el botón siempre a la vista.

## Usar

- **Clic en el icono**: guarda la página actual. Aparece un aviso verde arriba a la derecha y el icono marca ✓.
- **Atajo `Alt+Shift+R`**: lo mismo, sin tocar el ratón. Puedes cambiarlo en `chrome://extensions/shortcuts`.
- **Texto seleccionado**: si antes de pulsar seleccionas un trozo de texto de la página, se guarda como descripción.
- **Clic derecho**:
  - sobre la página → *Guardar página en Recursos*
  - sobre un enlace → *Guardar enlace en Recursos*
  - sobre una imagen → *Guardar imagen en Recursos* (la página queda como referencia y la imagen como portada)

El recurso se crea con tipo detectado automáticamente, estado *Pendiente* y prioridad *Media*.
Luego puedes ajustarlo desde la web con **Editar**.

Si la página ya estaba guardada, te lo dice (icono `=`) y no crea un duplicado.

## Importante

- Tienes que haber **iniciado sesión en la web de Recursos en ese mismo navegador**.
  La extensión usa esa sesión: no pide ni guarda contraseñas.
- Solo los **administradores** pueden guardar recursos (igual que en la web).
- No funciona en páginas internas del navegador (`chrome://…`, tienda de extensiones…): avisa con el icono `!`.

## Avisos del icono

| Icono | Significado |
|-------|-------------|
| ✓ verde | Guardado |
| = azul | Ya estaba guardado |
| ! ámbar | Falta iniciar sesión, o la página no se puede guardar |
| ! rojo | Sin permiso (no eres admin), sin conexión o error al guardar |

## Si cambias la dirección de la web

Hay que cambiarla en **dos sitios** y recargar la extensión (botón ⟳ en `chrome://extensions`):

1. `background.js`: la constante `APP_URL` de arriba del todo.
2. `manifest.json`: la lista `host_permissions`.

## Privacidad y permisos

- Solo habla con tu web (la dirección de `APP_URL`). No envía nada a ningún otro sitio.
- `activeTab` y `scripting`: leer el texto seleccionado y mostrar el aviso, solo en la pestaña donde pulsas.
- `contextMenus`: las opciones del clic derecho.
